document.addEventListener('DOMContentLoaded', () => {
  const navContainer = document.querySelector('.navUL');
  const items = Array.from(navContainer.children);

  // Function to reorder items when there are changes
  function reorderNavItems() {
    // Reset the container before reordering
    navContainer.innerHTML = '';
    items.forEach(item => navContainer.appendChild(item)); // Add items back in original order

    // Get the container's current width
    const containerWidth = navContainer.offsetWidth;

    // Group items into rows based on the container's width
    const rows = [];
    let currentRow = [];
    let currentRowWidth = 0;

    // Loop through each item and group them by width
    items.forEach(item => {
      const itemWidth = item.offsetWidth;

      // Check if adding this item exceeds the container width
      if (currentRowWidth + itemWidth > containerWidth) {
        rows.push(currentRow); // Push the current row to rows array
        currentRow = [item]; // Start new row with the current item
        currentRowWidth = itemWidth; // Reset the current row width with the new item's width
      } else {
        currentRow.push(item); // Add the item to the current row
        currentRowWidth += itemWidth; // Update the current row width
      }
    });

    // Push the last row if any
    if (currentRow.length > 0) {
      rows.push(currentRow);
    }

    // Clear the container to avoid duplicates
    navContainer.innerHTML = '';

    // Append rows, reversing every second row, but not the last one
    rows.forEach((row, index) => {
      // Reverse every second row (except for the last row)
      if (index % 2 !== 0 && index !== rows.length - 1) {
        row.reverse();
      }
      // Append each item of the row in order
      row.forEach(item => navContainer.appendChild(item));
    });
  }

  // Function to add a new li dynamically
  function addNavItem(newItemContent) {
    const newLi = document.createElement('li');
    const newAnchor = document.createElement('a');
    newAnchor.href = '#';
    newAnchor.classList.add('navA');
    newAnchor.textContent = newItemContent;
    newLi.appendChild(newAnchor);
    navContainer.appendChild(newLi);

    // Reorder after adding a new item
    reorderNavItems();
  }

  // Example: Dynamically adding a new item
  addNavItem('New Item');

  // Initial reorder on page load
  reorderNavItems();

  // Run reorder on window resize
  window.addEventListener('resize', reorderNavItems);

  // Set up a MutationObserver to detect changes (new items being added)
  const observer = new MutationObserver(() => {
    reorderNavItems(); // Reorder items whenever a mutation occurs
  });

  // Observe changes to the navUL container
  observer.observe(navContainer, {
    childList: true,  // Observe added or removed child nodes
    subtree: true,    // Observe the entire subtree
  });
});
